<hr>

<small>Copyright 2008 My Site</small><br>

</body>

</html>