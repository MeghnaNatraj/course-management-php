<html>


<head>initialise
</head>


<body>


 <?php
session_start();
$_SESSION["success"]=0;
$_SESSION["error"]=0;
header('Location: l.php');
?>


</body>


</html>
